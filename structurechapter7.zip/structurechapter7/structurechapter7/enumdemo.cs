﻿using System;

namespace structurechapter7
{
    class enumdemo
    {
        static void Main()
        {
           // Console.WriteLine(colors.red.GetHashCode());//Convert.ToInt32(colors.red)
            //Console.WriteLine(gst.Maharastra.GetHashCode());
            
            foreach(string name in Enum.GetNames(typeof(gst)))
            {
                Console.WriteLine(name);
            }

            foreach (int code in Enum.GetValues(typeof(gst)))
            {
                Console.WriteLine(code);
            }

            foreach (string m in Enum.GetNames(typeof(Mymonth.Months)))
            {
                Console.WriteLine(m);
            }

            foreach (int m1 in Enum.GetValues(typeof(Mymonth.Months)))
            {
                Console.WriteLine(m1);
            }


            Console.ReadLine();
        }
    }
}
