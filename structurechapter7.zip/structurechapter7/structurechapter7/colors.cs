﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace structurechapter7
{
    enum colors
    {
        red=120,green=200,blue=red
    }

    enum colors1
    {
        red=colors.green,green=200,blue=colors.blue
    }

    enum gst
    {
        Maharastra=27,Gujrat=24,Delhi=12,UP=30,MP=32,AP=40,Karanataka=36
    }
}
