﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace structurechapter7
{
    class interpolation
    {
        static void Main()
        {
            foreach (string name in Enum.GetNames(typeof(gst)))
            {
                Console.WriteLine($"Name of state is:{name}");
            }

            foreach (int code in Enum.GetValues(typeof(gst)))
            {
                Console.WriteLine(code);
            }
        }
    }
}
