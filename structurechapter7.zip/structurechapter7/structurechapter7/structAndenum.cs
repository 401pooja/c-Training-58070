﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace structurechapter7
{
    class structAndenum
    {
    }

    public struct Mymonth
    {
        public enum Months
        {
            jan=1,feb=2,march=3,april=4,may=5,jun=6,july=7,aug=8,sept=9,oct=10,nov=11,dec=12
        }
    }
    public struct Myyear
    {
        public enum Year
        {
            year=2019,year1=2018,year2=2017
        }
    }
}
