﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace structurechapter7
{
    class books
    {
        int isbn = 123;
        string name="c# 4.0";
    }
    struct Book
    {
        int isbn;
        string bookname;
        string authorname;

        public Book(int isbn,string bookname,string authorname)
        {
            this.isbn = isbn;
            this.bookname = bookname;
            this.authorname= authorname;
        }

        public string Display()
        {
            return string.Format("Book isbn={0} book name={1} author name={2} ", isbn, bookname, authorname);
        }
    }
}
