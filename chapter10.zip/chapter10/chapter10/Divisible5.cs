﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter10
{
    public static class Divisible5
    {
        public static bool IsPositive(this int i,int value)
        {
            return i < value;
        }
    }

    class MainExtension
    {
        static void Main()
        {
            Console.WriteLine("Enter the number");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number");
            int n1 = Convert.ToInt32(Console.ReadLine());
            bool result = n.IsPositive(n1);
            Console.WriteLine(result ? "Positive" : "Negative");
        }
    }
}
