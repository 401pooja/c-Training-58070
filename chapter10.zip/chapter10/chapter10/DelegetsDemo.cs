﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter10
{
    class DelegetsDemo
    {
        public delegate void Print(int value);
        static void Main()
        {
            Print printDel = new Print(PrintNumber);
            //printDel(100);
            //printDel = PrintRupees;
             //printDel(5000);
            printDel += PrintRupees;//calling two functions
            printDel -= PrintRupees;
            printDel(5000);


        }
        public static void PrintNumber(int num)
        {
            Console.WriteLine($"Number is{num}");
        }

        public static void PrintRupees(int rupees)
        {
            Console.WriteLine($"Rupees is { rupees}");
        }
    }
}
