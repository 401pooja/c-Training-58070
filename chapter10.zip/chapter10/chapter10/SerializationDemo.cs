﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace chapter10
{
    class SerializationDemo
    {
        static void Main()
        {
            //Dosealization();
            DoDesealization();
            Console.ReadLine();
        }

        public static void Dosealization()
        {
            Employee emp = new Employee();
            emp.ID = 100;
            emp.Name = "scott";
            emp.Gender = "m";
            FileInfo f = new FileInfo("employee.dat");
            Stream stream = f.Open(FileMode.Create);
            BinaryFormatter b = new BinaryFormatter();
            b.Serialize(stream, emp);
            Console.WriteLine("emo obj is serialized");
        }

        public static void DoDesealization()
        {
            Employee emp = new Employee();
            FileInfo f = new FileInfo("Employee.dat");
            Stream stream = f.Open(FileMode.Open);
            BinaryFormatter b = new BinaryFormatter();
            emp = (Employee)b.Deserialize(stream);
            Console.WriteLine($"ID={emp.ID} Name={emp.Name} Gender={emp.Gender}");

        }
    }
}
