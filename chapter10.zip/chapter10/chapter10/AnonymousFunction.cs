﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter10
{
    class AnonymousFunction
    {
        public delegate void Print(int value);
        static void Main()
        {
            Print p = delegate (int val)
              {
                  Console.WriteLine($"I'm from anonymous function {val}");
              };
            p(100);

        }
    }
}
