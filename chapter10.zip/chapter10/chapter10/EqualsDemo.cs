﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter10
{
    class EqualsDemo
    {
        static void Main()
        {
            int num1 = 20;
            double num2 = num1;
            Console.WriteLine(num1.Equals(num2));//it compairs value
            Console.WriteLine(num1 == num2);//it compairs ref
            Console.WriteLine(num1.GetHashCode());
            Console.WriteLine(num2.GetHashCode());
            Console.ReadLine();

        }
    }
}
