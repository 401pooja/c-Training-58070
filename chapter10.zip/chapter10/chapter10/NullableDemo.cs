﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter10
{
    class NullableDemo
    {
        static void Main()
        {
            //Nullable<int> num = null;
            // Nullable<int> num1 = 40;
            //Nullable<int> num3 = num + num1;
            int? num = 40;
            if (num.HasValue)
            {
                //Console.WriteLine(num);
                //Console.WriteLine(num1.GetValueOrDefault());
                Console.WriteLine(num.Value);
            }
            else
            {
                Console.WriteLine("object is null");
            }
            Console.WriteLine();

        }
    }
}
