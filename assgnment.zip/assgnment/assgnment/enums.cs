﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    

     struct CityName
    {
       public enum City
        {
            pune=411027,Niapani=591237,Kolhapur=531124
        }
    }
    
}
