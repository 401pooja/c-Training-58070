﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class jaggarrayfunction
    {
        static void Main()
        {
            Jagged();
        }
        public static void Jagged()
        {
            int[][] arr = new int[2][];
            arr[0] = new int[3] { 10, 20, 30 };
            arr[1] = new int[5] { 40, 50, 60, 70, 80 };

            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in arr[i])
                {
                    Console.WriteLine("{0}", temp);
                }
            }
            Console.WriteLine();

            Console.WriteLine("search jagg array:");
            int a = Convert.ToInt32(Console.ReadLine());

            int flag = 0;
            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in arr[i])
                {
                    if (a == temp)
                    {
                        flag = 1;
                    }
                    Console.WriteLine("{0}\t", temp);
                }
            }
            Console.WriteLine();

            if (flag == 1)
            {
                Console.WriteLine("number found:");
            }
            else
            {
                Console.WriteLine("number not found");
            }
            Console.WriteLine();






        
        }
    }
}
