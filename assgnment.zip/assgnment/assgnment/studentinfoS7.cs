﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
   
        struct Student
        {
            int rollno;
            string Name;
            string Gender;
            int Mno;

            public Student(int rollno, string Name, string Gender, int Mno)
            {
                this.rollno = rollno;
                this.Name = Name;
                this.Gender = Gender;
                this.Mno = Mno;
            }

            public string Display()
            {
                return string.Format("Rollno={0} Name={1} Gender={2} Mobileno={3} ", rollno, Name, Gender, Mno);
            }
        
    }
}
