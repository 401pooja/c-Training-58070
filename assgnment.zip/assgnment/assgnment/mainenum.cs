﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class mainenum
    {
        static void Main()
        {

            foreach (string cty in Enum.GetNames(typeof(CityName.City)))
            {
                Console.WriteLine(cty);
            }

            foreach (int std in Enum.GetValues(typeof(CityName.City)))
            {
                Console.WriteLine(std);
            }
        }
    }
}
