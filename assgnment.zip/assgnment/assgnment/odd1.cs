﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class odd1
    {
        static void Main()
        {
            int i = 50;
            do
            {
                if (i % 2 != 0)
                {
                    Console.WriteLine(i);
                }
                i--;
            }
            while (i >= 0);
        }
    }
}
