﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class factorialS6
    {
        static void Main()
        {
            factorialS6 f = new factorialS6();
            Console.WriteLine("Enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(f.Factorial(n));
            Console.WriteLine(n);

        }

        public int Factorial(int n)
            {
                int i, fact = 1;
                for (i = 0; i <= n; i++)
                {
                    fact = fact * i;
                }
                return fact;

            
        }
    }
}
