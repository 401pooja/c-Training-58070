﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class Switch1
    {
        static void Main()
        {
            Console.WriteLine("Enter no between 1 to 7:");
            int i = Convert.ToInt32(Console.ReadLine());
            switch(i)
            {
                case 1:Console.WriteLine("Monday");
                    break;
                case 2:
                    Console.WriteLine("Tue");
                    break;
                case 3:
                    Console.WriteLine("Wed");
                    break;
                case 4:
                    Console.WriteLine("Thu");
                    break;
                case 5:
                    Console.WriteLine("Fri");
                    break;
                case 6:
                    Console.WriteLine("Sat");
                    break;
                case 7:
                    Console.WriteLine("sun");
                    break;
                default:Console.WriteLine("Invalid no");
                    break;
            }
        }
    }
}
