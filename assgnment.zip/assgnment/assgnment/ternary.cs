﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class ternary
    {
        static void Main()
        {
            Console.WriteLine("Enter person age:");
            double p = Convert.ToInt32(Console.ReadLine());
            string r = p >= 20 ? "Major" : "Minor";
            Console.WriteLine(r);
        }
    }
}
