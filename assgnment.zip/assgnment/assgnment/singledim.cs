﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class singledim
    {
        static void Main()
        {
            int[] arr = new int[20];
            int sum = 0;
           
            

            Console.WriteLine("Enter elements of arr:");
            int n = Convert.ToInt32(Console.ReadLine());
            for (int i=0;i<n;i++)
            {
                Console.WriteLine("elements :{0}", i);
                arr[i]=Convert.ToInt32(Console.ReadLine());
            }
            for (int i = 0; i < n; i++)
            {
                sum = sum + arr[i];
            }
            Console.WriteLine("Sum of arr is:{0}", sum);





        }
    }
}
