﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class ascii
    {
        static void Main()
        {
           
            int[,] arr = new int[3][];
            arr[0] = new int[3];
            arr[1] = new int[3];
            arr[2] = new int[3];




        }
    }
}
