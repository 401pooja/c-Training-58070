﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class simpleinterestS6
    {
        public double SimpleInterest(double amount, double year, out double interest, double rate)
        {
            interest = amount * year * rate / 100;
            return interest;
        }

        


        public double Interest(double amount,double year,out double interest,double rate)
        {
            interest = amount * year * rate / 100;
            double Totalamount = amount + interest;
            return Totalamount;
        }

        static void Main()
        {
            simpleinterestS6 s = new simpleinterestS6();
            double interest;
            Console.WriteLine("Total amount:{0}",s.Interest(1000, 5, out interest, 2));
            Console.WriteLine("Total interest:{0}", interest);

        }
    }
}

