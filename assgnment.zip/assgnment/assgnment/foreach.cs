﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class foreach1
    {
        static void Main()
        {
            int[] arr = new int[50];
            for (int i = 0; i < 50; i++)
            {
                arr[i] = i+1;
            }
            foreach (int temp in arr)
            {
                if (temp % 2 != 0)
                {
                    Console.WriteLine(temp);
                }
            }

        }

    }
}
