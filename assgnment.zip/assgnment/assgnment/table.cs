﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class table
    {
        static void Main()
        {
            for(int i=1;i<=10;i++)
            {
                Console.WriteLine(i * 2);
            }
        }
    }
}
