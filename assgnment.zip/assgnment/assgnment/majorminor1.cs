﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class majorminor1
    {
        static void Main()
        {
            Console.WriteLine("Enter the age of person:");
            int p = Convert.ToInt32(Console.ReadLine());
            if (p >= 20)
            {
                Console.WriteLine("major");
            }
            else
            {
                Console.WriteLine("minor");
            }
        }
    }
}
