﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class mainclass
    {
        static void Main()
        {
            Student s = new Student(32, "pooja", "F", 123456789);
            Console.WriteLine(s.Display());
        }
       
    }
}
