﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class sumdiagonal
    {
        static void Main()
        {
            int sum = 0;
            int[,] arr= { { 10, 20, 30 }, { 40, 50, 60 },{ 70, 80, 90 } };
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", arr[i, j]);

                }
                Console.WriteLine();

            }
            Console.WriteLine("The output is:");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if(i==j)
                    {
                        sum = sum + arr[i, j];
                    }
                  
                }

            }
            Console.WriteLine(sum);
        }
    }
}
