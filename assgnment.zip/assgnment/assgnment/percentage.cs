﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class percentage
    {
        static void Main()
        {
            Console.WriteLine("Enter percentage:");
            double p = Convert.ToInt32(Console.ReadLine());
            if(p>=75)
            {
                Console.WriteLine("A+");


            }
            else if(p>=65)
            {
                Console.WriteLine("A");
            }
            else
            {
                Console.WriteLine("B");
            }

        }
    }
}
