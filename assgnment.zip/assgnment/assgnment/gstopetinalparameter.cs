﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assgnment
{
    class gstopetinalparameter
    {
        public string Gst(double amount,int percentage=1,string msg="Total amount withgst:")
        {
            double Totalamount = amount * percentage / 100;
            return string.Format("{0}{1}", msg, Totalamount);
        }

        static void Main()
        {
            gstopetinalparameter g = new gstopetinalparameter();
            Console.WriteLine("Enter the amount:");
            double d = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the rate:");
            int num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Gst:{0}", g.Gst(d,num));


        }
    }
}
