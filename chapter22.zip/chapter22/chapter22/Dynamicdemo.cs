﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class Dynamicdemo
    {
        static void Main()
        {
            dynamic num = 10;
            Console.WriteLine("type of num is {0}",num.GetType());
            string str = "abc";
            Console.WriteLine("type of str is {0}", str.GetType());
            Console.ReadLine();

        }
    }
}
