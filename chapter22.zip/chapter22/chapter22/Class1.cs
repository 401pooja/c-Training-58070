﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class Class1
    {
        static void Main()
        {
            Program p = new Program();
            Console.WriteLine(p.Message("hellow world"));
            p.Message();
            Console.ReadLine();
        }
    }

    class class22:Class1
    {

    }
}
