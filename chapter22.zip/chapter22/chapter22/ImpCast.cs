﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class ImpCast
    {
        static void Main()
        {
            int num = 50;
            double d = num;
            object obj = d;
            Console.WriteLine(obj);
            Console.ReadLine();

        }
    }
}
