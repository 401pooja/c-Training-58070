﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    /// <summary>
    /// This is simple class
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {

            //single line comment
            /*
             * 
             *
             */
        }
        /// <summary>
        /// this function print an test message
        /// </summary>
        public void Message()
        {
            Console.WriteLine("Hellow");
        }
        /// <summary>
        /// This function accepts text and print text
        /// </summary>
        /// <param name="str">simple text</param>
        /// <returns></returns>

        public string Message(string str)
        {
            return str;
        }
    }
}
