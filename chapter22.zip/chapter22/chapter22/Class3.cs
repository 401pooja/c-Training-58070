﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class Class3
    {
        static void Main()
        {
            string str = "50";
            int outvar;
            bool Iscom = int.TryParse(str, out outvar);
            if (Iscom)
            {
                Console.WriteLine(outvar);
            }
            else
            {
                Console.WriteLine("conversion is not compitible");
            }
            Console.ReadLine();
        }
        
    }
}
