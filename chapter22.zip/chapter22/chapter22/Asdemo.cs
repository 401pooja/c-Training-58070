﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class Asdemo
    {
        static void Main()
        {
            Object[] obj = { 10, 20, "abc" };
            string str = obj[2] as string;
            if(str!=null)
            {
                Console.WriteLine("abc");
            }
           
            Console.ReadLine();
        }
    }
}
