﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class ExpCast
    {
        static void Main()
        {
            double d = 34.6;
            // int num = (int)d;
            int num = Convert.ToInt32(d);
            Console.WriteLine(num);
            Console.ReadLine();
        }
    }
}
