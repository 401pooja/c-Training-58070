﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class Isdemo
    {
        static void Main()
        {
            int num = 10;
            int num1 = 30;
            Object num2 = 33;
            Console.WriteLine(num1 is int);
            Console.WriteLine(num is int);
            Console.WriteLine(num2 is int);
            Class1 c1 = new Class1();
            class22 c2 = new class22();
            Console.WriteLine(c2 is Class1);//True
            Console.ReadLine();

        }
    }
}
