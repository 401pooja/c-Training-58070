﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class unboxing
    {
        static void Main()
        {
            object obj = 30;
            int i = (int)obj;
            Console.WriteLine(i);
            Console.ReadLine();
        }
    }
}
