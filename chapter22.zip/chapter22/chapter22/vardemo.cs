﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class vardemo
    {
        static void Main()
        {
            object obj;
            var v = 10;
            int[] nums = { 10, 20, 30, 40 };
            var v1 = nums;
            foreach(var temp in v1)
            {
                Console.WriteLine(temp);
            }
            int num = 30;
            
            Console.WriteLine(num++);
            Console.ReadLine();
        }
    }
}
