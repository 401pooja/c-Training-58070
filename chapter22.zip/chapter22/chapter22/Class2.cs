﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class Class2
    {
        static void Main()
            {
            Type type = typeof(int);
            Console.WriteLine("int={0}", type);
            type = typeof(long);
            Console.WriteLine("Long={0}", type);
            type = typeof(short);
            Console.WriteLine("Short={0}", type);
            Console.ReadLine();
            

        }
    }
}
