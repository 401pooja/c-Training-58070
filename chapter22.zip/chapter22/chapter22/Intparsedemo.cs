﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class Intparsedemo
    {
        static void Main()
        {
            //string s = "50";
            Console.WriteLine("Enter a number");

            string s = Console.ReadLine();
            int num = int.Parse(s);
            Console.WriteLine(num);
            Console.ReadLine();

        }
    }
}
