﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter3
{
    class ternary
    {
        static void Main()
        {
            Console.WriteLine("Enter annual income in ruppees:");
            int annualincome = Convert.ToInt32(Console.ReadLine());
            //string result = annualincome >= 250000 ? "you are liable to pay I.T" : "you are not liable to pay I.T";
            string result = annualincome >= 250000 ? "you are liable to pay I.T" :(30000).ToString();
            Console.WriteLine(result);
        }
    }
}
