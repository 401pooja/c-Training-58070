﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter3
{
    class gotolabel1
    {
        static void Main()
        {
            int i = 1;
            int sum = 0;
 start:           if(i<=15)
            {
                sum += i;
                Console.WriteLine(sum);
                i++;
                goto start;
            }
            Console.ReadLine();
           
        }
    }
}
