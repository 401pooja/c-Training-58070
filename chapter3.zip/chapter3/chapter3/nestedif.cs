﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter3
{
    class nestedif
    {
        static void Main()
        {
            Console.WriteLine("enter qualification(UG | PG):");
            string qualification = Console.ReadLine();
            Console.WriteLine("Enter experience in month:");
            int month = Convert.ToInt32(Console.ReadLine());
            if (qualification == "PG")
            {
                if (month >= 12)
                {
                    Console.WriteLine("yopu are eligible for interview");
                }

                else
                {
                    Console.WriteLine("exp should greater than 12 months");
                }
            }
            else
            {
                Console.WriteLine("qualification should be PG");
            }
            Console.ReadLine();
        }
    }
}
