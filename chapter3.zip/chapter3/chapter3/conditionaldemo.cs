﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter3
{
    class conditionaldemo
    {
        static void Main()
        {
            Console.WriteLine("enter qualification(UG | PG):");
            string qualification = Console.ReadLine();
            Console.WriteLine("Enter experience in month:");
            int month = Convert.ToInt32(Console.ReadLine());
            if(qualification.ToLowerInvariant()=="PG" && month >= 12)
            {
                Console.WriteLine("you are eligible for interview");
            }
            else
            {
                Console.WriteLine("you are not eligible for interview");
            }
            Console.ReadLine();
        }

    }
}
