﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter3
{
    class gstdemo
    {
        static void Main()
        {
            Console.WriteLine("Enter amount");
            double amount = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter item");
            string item = Console.ReadLine();

            //Console.WriteLine("Enter item:(Food|Services|Orments)");
            //string item=Console.ReadLine();
            if(item=="Food")
            {
                Console.WriteLine("5%");
            }
            else if(item=="Services")
            {
                Console.WriteLine("4%");
            }
            else if (item == "Orments")
            {
                Console.WriteLine("12%");
            }
            else
            {
                Console.WriteLine("Invalid item");
            }
            Console.ReadLine();
        }
    }
}
