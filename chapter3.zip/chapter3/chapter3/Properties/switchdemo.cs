﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter3.Properties
{
    class switchdemo
    {
        static void Main()
        {
            Console.WriteLine("Enter item:(Food|Services|Orments)");
            string item=Console.ReadLine();

            switch(item)
            {
                case "Food":Console.WriteLine("5%");
                    break;
                case "Services":
                    Console.WriteLine("4%");
                    break;
                case "Orments":
                    Console.WriteLine("12%");
                    break;
                default: Console.WriteLine("Invalid item");
                    break;

            }
            Console.ReadLine();
        }

    }
}
