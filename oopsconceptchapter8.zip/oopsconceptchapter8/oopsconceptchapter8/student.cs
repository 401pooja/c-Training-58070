﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class student
    {
        private int Rollno;
        private string Name;

        //propertys shouls be public
        public int stdRollno
        {
            get
            {
                return Rollno;
            }
            set
            {
                Rollno = value;
            }
        }

        public string stdName
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
                if (value == "")
                {

                    Console.WriteLine("Invalid name");
                }
                else
                {
                    Name = value;
                }

            }
        }

        public string Schoolname
        {
            get
            {
                return "MGM";
            }
        }

    }
}
