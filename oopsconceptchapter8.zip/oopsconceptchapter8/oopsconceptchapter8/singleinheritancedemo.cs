﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class singleinheritancedemo
    {
        static void Main()
        {
            Create();
            GC.Collect();
            Console.ReadLine();
        }

        public static void Create()
        {
            inheritanceNokia1400 n = new inheritanceNokia1400();
            Console.WriteLine(n.Calling());
            Console.WriteLine(n.SMS());
        }
    }
}
