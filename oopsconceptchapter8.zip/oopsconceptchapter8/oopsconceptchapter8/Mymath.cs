﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class Mymath
    {
        public int Add(int num1,int num2)
        {
            return num1 + num2;
        }
        public string Add(string str1,string str2)
        {
            return str1 + str2;
        }

        public virtual int Increment(int x)
        {
            x++;
            return x;
        }
    }

    class Mymath2:Mymath
    {
        public override int Increment(int x)
        {
            x = x + 10;
            return x;
        }
        public new double Add(double d1,double d2)//new keyword denotes shadoing
        {
            return d1 + d2;
        }
    }
    class Mymath3 : Mymath
    {
        public sealed override int Increment(int x)//final concri we not use again
        {
            x = x + 50;
            return x;
        }

    }
}
