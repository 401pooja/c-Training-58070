﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    static class employee
    {
        static employee()
        {
            Console.WriteLine("default constructor of employee");
        }
        public static string Details(int Empcode,string Name)
        {
            return string.Format("employee code is {0} and name is {1}", Empcode, Name);
        }
    }

    class staticDemo
    {
        static void Main()
        {
            //employee e = new employee();
            Console.WriteLine(employee.Details(100,"Tiger"));
        }
    }
}
