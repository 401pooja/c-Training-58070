﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class HirarchyNOKIA2700: mobilephones
    {
        public HirarchyNOKIA2700()
        {
            Console.WriteLine("Default constructor of NOKIA2700");
        }
       
        public string MP4()
        {
            return "MP4 calling from NOKIA2700";
        }

        public string Camera1()
        {
            return "Camera calling from NOKIA2700";
        }

        ~HirarchyNOKIA2700()
        {
            Console.WriteLine(" garbege is collecting from NOKIA2700");
        }
    }
}
