﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
   interface IWFI
    {
        string startWIFI();
        string stopWIFI();

    }
    class NOKIALUMIA:mobilephones,IWFI
    {
        public string startWIFI()
        {
            return "starting WIFI";
        }
        public string stopWIFI()
        {
            return "stopping WIFI";
        }
        

    }

    class NOKIALUMIA2:NOKIALUMIA
    {
        public string pushmessage()
        {
            return "calling from nokianuma2.Pushmessage";
        }
    }

    class interfacedemo
    {
        static void Main()
        {
            //IWFI i = new NOKIALUMIA();
            NOKIALUMIA n = new NOKIALUMIA();
            Console.WriteLine(n.startWIFI());
            Console.WriteLine(n.stopWIFI());
            Console.WriteLine(n.Calling());
            //Console.WriteLine(i.startWIFI());
            //Console.WriteLine(i.stopWIFI());
            NOKIALUMIA2 n2 = new NOKIALUMIA2();
            Console.WriteLine(n2.pushmessage());
            Console.WriteLine(n2.startWIFI());
            Console.WriteLine(n2.stopWIFI());
            Console.WriteLine(n2.SMS());

        
            

        }
    }
       

}
