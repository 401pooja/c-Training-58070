﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class functionoverRidingdemo
    {
        static void Main()
        {
            Mymath2 m2 = new Mymath2();
            Console.WriteLine(m2.Increment(10));
            Console.WriteLine(m2.Add(11.5, 12.6));
        }
    }
}
