﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class multelevelNokia1100: inheritanceNokia1400
    {
        public multelevelNokia1100()
        {
            Console.WriteLine("Default constructor NOKIa1100");
        }

        public string MP3()
        {
            return "Callig MP# from NOKIA1100";
        }

        public string Camera()
        {
            return "CAmera in NOKIA1100";
        }
    }
}
