﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    abstract class vehicle
    {
        public vehicle()
        {
            Console.WriteLine("Default constructor of vehicle");
        }
        public string start()
        {
            return "starting vehicle";
        }
        public string stop()
        {
            return "stoping vehicle";
        }

        public abstract string start(string type);
    }
     sealed class Fourwheeler:vehicle//abstract demo cant derived for sealed class
    {
        public override string start(string type)
        {
            return $"this will start using{type}";
        }
    }

    class Abstractdemo
    {
        static void Main()
        {
            //vehicle v1 = new vehicle();//error
            Fourwheeler f = new Fourwheeler();
            Console.WriteLine(f.start());
            Console.WriteLine(f.stop());
            Console.WriteLine(f.start("key"));

        }
    }
}
