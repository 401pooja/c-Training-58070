﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class functionoverloadingdemo
    {
        static void Main()
        {
            Mymath m = new Mymath();
            Console.WriteLine(m.Add(20, 30));
            Console.WriteLine(m.Add("hellow", "world"));
            Console.ReadLine();

        }
    }
}
