﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class propertydemo
    {
        static void Main()
        {
            //public int MyProperty { get; set; }//double click onTab
           student std = new student();
            std.stdRollno = 100;
            std.stdName = "scott";
            Console.WriteLine("{0}{1}", std.stdRollno,std.stdName);
        }
    }
}
