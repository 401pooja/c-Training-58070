﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class Program
    {
        static void Main(string[] args)
        {
            Createmobile();

            GC.Collect();
            Console.ReadLine();
        }

        public static void Createmobile()
        {
            mobilephones m = new mobilephones();
            mobilephones m1 = new mobilephones(1234, "NoKIa7", "ABCc1234");
            //Console.WriteLine(m1.Display());
            Console.WriteLine(m1.ToString());
        }
    }
}
