﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class mobilephones
    {
        int Modelno;
        string Modelname;
        string IMEINO;

        public mobilephones()//constructor
        {
            Console.WriteLine("Default constructer of mobile");
        }

        public mobilephones(int Modelno,string Modelname,string IMEINO)
        {
            this.Modelno = Modelno;
            this.Modelname = Modelname;
            this.IMEINO = IMEINO;

            
        }

        public string Display()
        {
            return string.Format("MOdelno={0} Name={1} IMEIno={2}", Modelno, Modelname, IMEINO);
        }

        public string Calling()
        {
            return "this is calling from mobilephones";
        }
        public string SMS()
        {
            return "sending msg";
        }

        public override string ToString()
        {
            return string.Format("MOdelno={0} Name={1} IMEIno={2}", Modelno, Modelname, IMEINO);
        }
        ~mobilephones()//destructor
        {
            Console.WriteLine("Garbage is collecting for Mobile instance");
        }
    }
}
