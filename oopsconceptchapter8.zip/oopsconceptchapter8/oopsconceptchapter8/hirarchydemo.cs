﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class hirarchydemo
    {
        static void Main()
        {
            Display();
            GC.Collect();
            Console.ReadLine();
        }

        public static void Display()
        {
            HirarchyNOKIA2700 h = new HirarchyNOKIA2700();
            inheritanceNokia1400 n = new inheritanceNokia1400();

            Console.WriteLine(h.MP4());
            Console.WriteLine(h.Camera1());
        }
    }
}
