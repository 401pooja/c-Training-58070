﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class multileveldemo
    {
        static void Main()
        {
            Display();
            Console.ReadLine();
        }

        public static void Display()
        {
            multelevelNokia1100 m = new multelevelNokia1100();
            Console.WriteLine(m.MP3());
            Console.WriteLine(m.Camera());
        }
    }
}
