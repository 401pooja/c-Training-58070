﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsconceptchapter8
{
    class inheritanceNokia1400:mobilephones
    {
        public inheritanceNokia1400()
        {
            Console.WriteLine("Default constructor of Nokia1400");
        }
        public string Radio()
        {
            return "calling radio from Nokia1100";
        }
        ~inheritanceNokia1400()
        {
            Console.WriteLine("garbege is collected from NOKIA1400 instance");
        }
    }
}
