﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class dollar
    {
        static void Main()
        {
            double d = 3;

            int rs = Convert.ToInt32(d * 80);
            Console.WriteLine("Rupees:{0}", rs);
            int r = 100;
            double dollar = r / 80;
            
            Console.WriteLine("dollar:{0}", dollar);

        }
    }
}
