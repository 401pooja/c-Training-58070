﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class Asciidemo
    {
        static void Main()
        {
            char ch = 'A';
            
            Console.WriteLine("{0}",(int)ch);
            int i = 65;
            Console.WriteLine("{0}", (char)i);



            Console.ReadLine();

        }
    }
}
