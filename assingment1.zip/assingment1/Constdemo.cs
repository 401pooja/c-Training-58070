﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter22
{
    class Constdemo
    {
        static void Main()
        {
            const double PI = 3.14;//must be initi
            //PI=3.14;//cant assigned
            int r = 5;
            double aoc = r * r * PI;
            Console.WriteLine(aoc);
            Console.ReadLine();
        }
    }
}
