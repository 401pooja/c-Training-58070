﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter4
{
    class Class1
    {
        static void Main()
        {
            int[] nums = { 1, 2, 3, 4, 5, 6 };
            foreach(int temp in nums)
            {
                Console.WriteLine(temp);
            }
        }
    }
}
