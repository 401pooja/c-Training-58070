﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter4
{
    class Foreach
    {
        static void Main()
        {
            string[] names = { "sachin", "Rahul", "zeehar","veer","virat" };
            foreach(string temp in names)
            {
                if(temp.ToLowerInvariant()=="virat")
                {
                    Console.WriteLine(temp);
                }
                
            }
            for(int i=0;i<5;i++)
            {
                Console.WriteLine(names[i]);
            }
            int[] nums = { 10, 20, 30, 40, 50 };
            foreach(var temp in nums)
            {
                Console.WriteLine(temp);
            }

            object[] obj = { 10, 20, "abc", "A", 50 };
            var v = obj;
            foreach (var temp in v)
            {
                Console.WriteLine(temp);
            }
            Console.ReadLine();
        }
    }
}
