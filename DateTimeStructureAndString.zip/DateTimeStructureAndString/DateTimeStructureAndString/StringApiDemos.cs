﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DateTimeStructureAndString
{
    class StringApiDemos
    {
        static void Main()
        {
            string str = "welcome to string class";
            // string str1 = string.Empty;
            string str1 = string.Copy(str);
            //char[] chars = str.ToCharArray();
            //str.CopyTo(0, chars, 0, str.Length);
            Console.WriteLine(str1);
            string toSearch = "welcome";
            if (str.StartsWith(toSearch, StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("yes");
            }

            string newstr = str.Substring(8, 15);
            string newmystr = string.Empty;
            Console.WriteLine($"sub string is:{newstr}");

            foreach (string s in str.Split(' '))
            {
                newmystr += s;
            }

            
            
            Console.WriteLine($" string After removing white spaces:{newmystr}");


            
             
            Console.ReadLine();
        }
    }
}
