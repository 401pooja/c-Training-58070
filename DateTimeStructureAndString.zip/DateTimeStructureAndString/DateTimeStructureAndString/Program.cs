﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTimeStructureAndString
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"system date and time:{DateTime.Now}");
            Console.WriteLine($"System Date:{DateTime.Now.Date.ToString("dd-MMM-yyyy")}");
            Console.WriteLine($"Day:{DateTime.Now.Date.Day} Month:{DateTime.Now.Date.Month} Year:{DateTime.Now.Date.Year}");
            Console.WriteLine($"After Adding 5 days:{DateTime.Now.Date.AddDays(5).ToString("dd-MM-yyy")}");
            DateTime mydate = new DateTime(2019,10,14);
            int no=mydate.CompareTo(DateTime.Now.Date);
            if(no==0)
            {
                Console.WriteLine($"{mydate.Date} and {DateTime.Now.Date} Both date are equal");
            }
            else if(no==1)
            {
                Console.WriteLine($"{mydate.Date} is newer than {DateTime.Now.Date}");
            }
            else
            {
                Console.WriteLine($"{mydate.Date} is older than {DateTime.Now.Date}");
            }

            double date1=mydate.Date.ToOADate();
            double date2 = DateTime.Now.Date.ToOADate();
            double days = date2 - date1;
            Console.WriteLine($"span in days:{days}");



            Console.ReadLine();
        }
    }
}
