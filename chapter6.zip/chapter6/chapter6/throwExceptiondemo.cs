﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class throwExceptiondemo
    {
        static void Main()
        {
            try
            {
                employee emp = new employee();
                emp.PrintName(" ");
               
            }
            catch(NullReferenceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();


        }

    }
}
