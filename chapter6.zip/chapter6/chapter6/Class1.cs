﻿using System;

namespace chapter6
{
    class Class1
    {
        public void Message()
        {
            Console.WriteLine("This is test message");
        }
        public int Add(int num1,int num2)
        {
            //return num1 + num2;
            return num1/num2;
        }
        public double Add(double d1,double d2)
        {
            return d1 + d2;
        }
        public int Increment(int x)
        {
            x++;
            return x;

        }
  public int Increment(ref int x)
        {
            x++;//num++
            return x;

        }

        public int Myfunction(out int x,out int y)
        {
            x = 10;
            y = 30;
            int z = 100;
            return z;
        }

        public double MyFunction(out double amount,double allamount,double percentage)
        {

            double Totalamount =allamount* percentage / 100;
            amount = Totalamount + allamount;
            return Totalamount;
                

        }

        public string Size(int height,int width=1,string msg="Size is:")//named parameter
        {
            return string.Format("{0} {1}",msg,height * width);
        }

        public void Marks1(int[] marks)
        {
            foreach (int temp in marks)
            {
                Console.WriteLine(temp);
            }
        }

        public void Marks(params int[] marks)
        {
            foreach(int temp in marks)
            {
                Console.WriteLine(temp);
            }
        }

        public void Myrecfun(int x)
        {
            if(x <=10)
            {
                Console.WriteLine(x);
                x++;
                Myrecfun(x);

            }
        }
    }
}
