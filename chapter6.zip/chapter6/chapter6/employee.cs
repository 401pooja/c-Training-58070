﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class employee
    {
        public void PrintName(string Name)
        {
            if(Name=="")
            {
                throw new NullReferenceException("Employee name is null");
            }
        }

        public void Validateempcode(int Empcode)
        {
            if (Empcode <= 0)
            {
                throw new invalidemployeecode();
            }
        }

       

    }
}
