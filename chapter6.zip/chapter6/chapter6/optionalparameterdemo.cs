﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class optionalparameterdemo
    {
        static void Main()
        {
            Class1 m = new Class1();
            Console.WriteLine(m.Size(20, msg: "This is answer"));
            Console.WriteLine("sizeof is {0}", m.Size(20));
        }
    }
}
