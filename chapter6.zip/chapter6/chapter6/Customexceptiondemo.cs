﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class Customexceptiondemo
    {
        static void Main()
        {
            try
            {
                employee emp = new employee();
                emp.Validateempcode(0);
                Console.ReadLine();
            }
            catch (invalidemployeecode ex)
            {
                Console.WriteLine(ex.Message);

            }
            Console.ReadLine();
        }
    }
}
