﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 m = new Class1();
            m.Message();
            int num1 = 10, num2 = 20;
            int sum=m.Add(num1, num2);
            Console.WriteLine(sum);
        }
    }
}
