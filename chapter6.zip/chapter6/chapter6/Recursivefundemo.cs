﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class Recursivefundemo
    {
        static void Main()
        {
            Class1 m = new Class1();
            m.Myrecfun(1);
        }
    }
}
