﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class student
    {
        public void Studentdetails(int RollNo, string SName)
        {
            if (RollNo < 100 && SName == "")
            {
                throw new invalidstudentcode();
            }

        }
    }
}
