﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class outdemo
    {
        static void Main()
        {
            Class1 m = new Class1();
            int num,num1;
            Console.WriteLine(m.Myfunction(out num,out num1));
            Console.WriteLine(num);
            Console.WriteLine(num1);
           
            



            //int a;
           // string str = 20;
            //int.TryParse(str, out a);
           // Console.WriteLine(a);
            

            
        }
    }
}
