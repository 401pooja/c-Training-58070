﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class Settingsdemo
    {
        public int sum;//instance level variable;
        static void Main()
        {
            Login();
            Userdetails();
        }
        public static void Login()
        {
            chapter6.Properties.Settings1.Default.Username = "scott";
        }

        public static void Userdetails()
        {
            string name = chapter6.Properties.Settings1.Default.Username;
            Console.WriteLine("welcome:{0}", name);
        }

        public static void Myfun(int x)//function leveel variable
        {
            if(true)
            {
                int y = 10;//scope level variable
            }
        }
    }
}
