﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class studenttrowexception
    {
        static void Main()
        {
            try
            {
                student s = new student();
                s.Studentdetails(10, " ");
            }
             catch(invalidstudentcode ex)
            {
                Console.WriteLine(ex.Message);
            }
            
    
             Console.ReadLine();

        }

    }
}
