﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class invalidemployeecode:Exception//custom class
    {
        public invalidemployeecode() :base("Invalid employee code")//base keyword
        {

        }
       
    }
}
