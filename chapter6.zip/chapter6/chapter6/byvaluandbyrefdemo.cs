﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class Byvaluandbyrefdemo
    {
        static void Main()
        {
            Class1 m = new Class1();
            int num = 99;
            Console.WriteLine(m.Increment(ref num));
            Console.WriteLine(num);
        }

        

    }
}
