﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class exceptiondemo
    {
        static void Main()
        {
            try
            {
                Class1 m = new Class1();
                int num1 = Convert.ToInt32(Console.ReadLine());
                int num2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(m.Add(num1, num2));
                Console.ReadLine();
            }
            catch(FormatException ex)
            {
                Console.WriteLine("please inter valid no");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Im in finally");
            }

        }
            
    }
}
