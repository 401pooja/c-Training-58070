﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class gstcalculationdemo
    {
        static void Main()
        {
            Class1 c = new Class1();
            double amount;
            Console.WriteLine("amount of gst {0}",c.MyFunction(out amount, 1000,5));
            Console.WriteLine("Total amount with gst{0}", amount);
        }
    }
}
