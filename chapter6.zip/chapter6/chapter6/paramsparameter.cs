﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter6
{
    class paramsparameter
    {
        static void Main()
        {
            Class1 m1 = new Class1();
            int[] mymarks = { 50, 60, 70 };//Traditional way
            m1.Marks1(mymarks);
            Console.ReadLine();

            Class1 m = new Class1();
            m.Marks(50, 60, 70, 80);
            Console.ReadLine();
            
        }
    }
}
